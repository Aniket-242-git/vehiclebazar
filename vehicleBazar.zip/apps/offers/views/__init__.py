"""Offers views package."""
